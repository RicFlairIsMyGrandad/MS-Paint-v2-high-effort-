import { canvas } from './raster.js';
import { bubbleGeometry, tailGeometry } from './shapes.js';
export const runStyleKeys = ['font','fontSize','fontUnit','bold','italic','underline','strikeout','textColor'];
export const pointsToPixels = value => value * 96 / 72;
export const shadowOffset = object => object.bubble && object.bubbleShadow ? Math.max(0, Math.min(100, Math.round(Number(object.shadowOffset) || 0))) : 0;
export function underlineThickness(run) {
  const points = run.fontUnit === 'pt' ? Number(run.fontSize) || 12 : (Number(run.fontSize) || 20) * 72 / 96;
  return Math.max(1, Math.floor(points / 8));
}
const underlineY = (run, baseline) => baseline + Math.max(1, Math.round(run.pixels * .1));
export function runStyle(object) {
  return Object.fromEntries(runStyleKeys.map(key => [key, object[key]]));
}
export function fontCSS(style) {
  const family = style.font || 'Segoe UI', pixels = style.fontUnit === 'pt' ? pointsToPixels(Number(style.fontSize) || 12) : Number(style.fontSize) || 20;
  const fallback = /Serif|Roman|Georgia|Garamond|Cambria|Baskerville|Book Antiqua|Palatino|Lora|Merriweather/i.test(family) ? 'serif' : /Mono|Consolas|Courier/i.test(family) ? 'monospace' : 'sans-serif';
  return `${style.italic ? 'italic ' : ''}${style.bold ? 'bold ' : ''}${Math.max(1,Math.min(512,pixels))}px "${family}", ${fallback}`;
}
export function coalesceRuns(runs) {
  const result = [];
  for (const run of runs) {
    if (!run.text) continue;
    const previous = result.at(-1);
    if (previous && runStyleKeys.every(key => previous[key] === run[key])) previous.text += run.text;
    else result.push({ ...run });
  }
  return result;
}
export function textRuns(object) {
  const base = runStyle(object);
  if (Array.isArray(object.textRuns) && object.textRuns.map(run => run.text).join('') === (object.text || '')) return coalesceRuns(object.textRuns.map(run => ({ ...base, ...run })));
  return [{ ...base, text: object.text || '' }];
}
export function formatRuns(runs, start, end, patch) {
  let offset = 0;const result = [];
  for (const run of runs) {
    const left = Math.max(0,start-offset), right = Math.min(run.text.length,end-offset);
    if (right > left) {
      result.push({ ...run, text: run.text.slice(0,left) });
      result.push({ ...run, ...patch, text: run.text.slice(left,right) });
      result.push({ ...run, text: run.text.slice(right) });
    } else result.push({ ...run });
    offset += run.text.length;
  }
  return coalesceRuns(result);
}
export function richLayout(object) {
  const boxWidth = Math.max(object.bubble ? 80 : 30,Math.round(object.textBoxWidth || object.width || 260)), padding = object.bubble ? Math.max(0,Math.min(100,Number(object.padding)||0)) + (Number(object.bubbleWidth)||3) + 2 : 0;
  const available = Math.max(1,boxWidth-padding*2), context=canvas(1,1).getContext('2d'), base=runStyle(object), runs=textRuns(object), characters=[];
  for(const run of runs) for(const character of Array.from(run.text.replace(/\r\n?/g,'\n'))) characters.push({character,style:run});
  const groups = chars => coalesceRuns(chars.map(item=>({...item.style,text:item.character})));
  const measure = chars => groups(chars).reduce((sum,run)=>{context.font=fontCSS(run);return sum+context.measureText(run.text).width;},0);
  const lines=[];let line=[], lastBreak=-1;
  for(const item of characters) {
    if(item.character==='\n'){lines.push(line);line=[];lastBreak=-1;continue;}
    line.push(item);
    if(/\s/.test(item.character))lastBreak=line.length-1;
    if(line.length>1 && measure(line)>available) {
      const cut=lastBreak>=0 && lastBreak<line.length-1?lastBreak+1:line.length-1;
      lines.push(line.slice(0,cut));line=line.slice(cut);
      while(line[0] && /\s/.test(line[0].character))line.shift();
      lastBreak=-1;line.forEach((item,index)=>{if(/\s/.test(item.character))lastBreak=index;});
    }
  }
  lines.push(line);
  let baseline=0,previousDescent=0,previousLeading=0,bottom=0;const rows=[];
  for(const chars of lines) {
    const segments=groups(chars);if(!segments.length)segments.push({...base,text:''});
    let ascent=0,descent=0,actualDescent=0,pixels=0;
    for(const segment of segments) {
      context.font=fontCSS(segment);const metrics=context.measureText('Mg'),actual=context.measureText(segment.text||'Mg');
      segment.font=fontCSS(segment);segment.pixels=segment.fontUnit==='pt'?pointsToPixels(Number(segment.fontSize)||12):Number(segment.fontSize)||20;
      segment.width=context.measureText(segment.text).width;
      ascent=Math.max(ascent,metrics.fontBoundingBoxAscent||metrics.actualBoundingBoxAscent||segment.pixels*.8);
      descent=Math.max(descent,metrics.fontBoundingBoxDescent||metrics.actualBoundingBoxDescent||segment.pixels*.2);
      actualDescent=Math.max(actualDescent,actual.actualBoundingBoxDescent||0);pixels=Math.max(pixels,segment.pixels);
    }
    const leading=Math.max(0,pixels*1.15-ascent-descent), gap=Math.max(-100,Math.min(200,Number(object.lineGap)||0));
    baseline=rows.length?baseline+Math.max(1,previousDescent+ascent+(previousLeading+leading)/2+gap):padding+ascent;
    const row={segments,baseline:Math.round(baseline),ascent,descent,text:chars.map(item=>item.character).join('')};
    rows.push(row);bottom=Math.max(bottom,row.baseline+actualDescent);
    for(const segment of segments)if(segment.underline)bottom=Math.max(bottom,underlineY(segment,row.baseline)+underlineThickness(segment));
    previousDescent=descent;previousLeading=leading;
  }
  const bodyHeight=Math.max(1,Math.ceil(bottom+padding+1));
  const tail=tailGeometry(object,boxWidth),tailHeight=tail.tipY;
  const boxHeight=Math.ceil(Math.max(object.minHeight||1,object.bubble?Math.max(18,bodyHeight)+tailHeight+2:bodyHeight)), offset=shadowOffset(object);
  const bodyX=object.bubble?Math.max(0,Math.ceil(-tail.tipX+2)):0,extraRight=object.bubble?Math.max(0,Math.ceil(tail.tipX-boxWidth+2)):0;
  const pixels=base.fontUnit==='pt'?pointsToPixels(Number(base.fontSize)||12):Number(base.fontSize)||20;
  return {width:boxWidth+bodyX+extraRight+offset,height:boxHeight+offset,boxWidth,boxHeight,bodyX,tail,bodyHeight:object.bubble?boxHeight-tailHeight:boxHeight,padding,rows,lines:rows.map(row=>row.text),font:fontCSS(base),fontSize:pixels,lineHeight:Math.max(1,pixels*1.15+(Number(object.lineGap)||0))};
}
export function paintRichText(context,layout) {
  const ink=canvas(layout.width,layout.height),glyphs=ink.getContext('2d'),decorations=[];
  glyphs.textBaseline='alphabetic';
  for(const row of layout.rows) {
    let x=layout.padding+(layout.bodyX||0);
    for(const run of row.segments) {
      glyphs.font=run.font;glyphs.fillStyle=run.textColor||'#000000';const left=Math.round(x);
      glyphs.fillText(run.text,left,row.baseline);
      const thickness=underlineThickness(run),width=Math.max(1,Math.round(run.width));
      if(run.underline)decorations.push({x:left,y:underlineY(run,row.baseline),width,thickness,color:run.textColor||'#000000'});
      if(run.strikeout) {glyphs.fillRect(left,row.baseline-Math.round(run.pixels*.3),width,thickness);}
      x+=run.width;
    }
  }
  if(decorations.length) {
    const inkPixels=glyphs.getImageData(0,0,ink.width,ink.height).data;
    for(const line of decorations) {
      const pixels=context.createImageData(line.width,line.thickness),rgb=[1,3,5].map(index=>parseInt(line.color.slice(index,index+2),16));
      for(let y=0;y<line.thickness;y++)for(let x=0;x<line.width;x++) {
        let touches=false;
        for(let dy=-1;dy<=1&&!touches;dy++)for(let dx=-1;dx<=1;dx++) {
          const px=line.x+x+dx,py=line.y+y+dy;
          if(px>=0&&py>=0&&px<ink.width&&py<ink.height&&inkPixels[(py*ink.width+px)*4+3]){touches=true;break;}
        }
        if(!touches){const index=(y*line.width+x)*4;pixels.data.set(rgb,index);pixels.data[index+3]=255;}
      }
      const strip=canvas(line.width,line.thickness);strip.getContext('2d').putImageData(pixels,0,0);context.drawImage(strip,line.x,line.y);
    }
  }
  context.drawImage(ink,0,0);
}
